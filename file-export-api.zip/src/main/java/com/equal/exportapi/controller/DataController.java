
package com.equal.exportapi.controller;

import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/data")
public class DataController {

    @GetMapping("/hello")
    public String hello(){
        return "API is running.";
    }
}
