# File Export API

A minimal Spring Boot project (Maven) that exposes a `Person` API and export endpoints for JSON, CSV, Excel, PDF, and plain text.

## Run

Build and run:

```bash
mvn clean package
java -jar target/file-export-api-1.0.0.jar
```

Or with Docker:

```bash
docker build -t file-export-api .
docker run -p 8080:8080 file-export-api
```

Open Swagger UI: http://localhost:8080/swagger-ui/index.html

Endpoints:
- GET /api/persons
- POST /api/persons
- GET /api/persons/{id}
- DELETE /api/persons/{id}
- GET /api/persons/export/csv
- GET /api/persons/export/excel
- GET /api/persons/export/pdf
- GET /api/persons/export/txt
